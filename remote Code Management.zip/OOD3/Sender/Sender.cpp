/////////////////////////////////////////////////////////////////////////
// Sender.cpp - C++ wrapper for creating messages.                     //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
#include "Sender.h"
#include "../filesystem\FileSystemDemo/FileSystem.h"
void Sender::conmsg(Socket &s,std::string name)
{
	Message *mess=new Message();
	mess->setcommand("upload");
	mess->setclientip("localhost");
	mess->setclientport("9080");
	mess->setserverip("localhost");
	mess->setserverport("9080");
	mess->setfilename(name);
	std::string cmd = mess->getcommand();
	std::string cip = mess->getclientip();
	std::string cport = mess->getclientport();
	std::string sip = mess->getserverip();
	std::string sport = mess->getserverport();
	std::string fname = mess->getfilename();
	//std::string fbody = mess->getfilebody();
	std::string message = "command:" + cmd + "\tclientip:" + cip + "\tclientport:" + cport + "\tserverip:" + sip + "\tserverport" + sport + "\tfilename" + fname + "filebody:";
	std::string p = name;
	std::string t = FileSystem::Directory::getCurrentDirectory();
	std::string pt = FileSystem::Path::getFullFileSpec(p);
	FileSystem::File file1(pt);
	file1.open(file1.in, file1.text);
	while (file1.isGood())
	{
		std::string msg1;
		std::string line=file1.getLine();
		msg1 = message + line;
		msg1 = msg1 + "*";
		if (file1.isGood() == FALSE)
		{

			msg1 = msg1 + "$";
			s.sendString(msg1);
		}
		else
			s.sendString(msg1);
	}
	
	
}
#ifdef TEST_Sender
int main()
{
	Sender *s = new Sender();
	Socket sock;
	std::string n;
	s->conmsg(sock,n);
}
#endif