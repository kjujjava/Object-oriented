/////////////////////////////////////////////////////////////////////////
// Sender.h - Sender package is  for creating messages                 //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  Provides class that creates messages from a given file
*  Constructmsg():
*  Constructs messages taking each line from a file with a message header.
*  Required Files:
*  ---------------
*  Message.h, Message.cpp, Socket.h, Socket.cpp
*  Sender.h, Sender.cpp
*  AppHelpers.h, AppHelpers.cpp, WindowsHelpers.h, WindowsHelpers.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9th Apr 15
*/

#pragma once
#include "../sockets/Sockets/Sockets.h"
#include "../Message/Message.h"
class Sender
{
public:
	Sender(){};
	~Sender(){};
	void conmsg(Socket &s,std::string name);
	
private:
	/*Message *mess;
	std::string cmd = mess->getcommand();
	std::string cip = mess->getclientip();
	std::string cport = mess->getclientport();
	std::string sip = mess->getserverip();
	std::string sport = mess->getserverport();
	std::string fname = mess->getfilename();
	std::string fbody = mess->getfilebody();
	std::string message = "command:" + cmd+"\tclientip:"+cip+"\tclientport:"+cport+"\tserverip:"+sip+"\tserverport"+sport+"\tfilename"+fname+"filebody:";*/
	
};

