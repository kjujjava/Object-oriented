#pragma once
class Executive
{
public:
	Executive();
	~Executive();
};

