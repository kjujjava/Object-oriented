#pragma once
class Display
{
public:
	Display();
	~Display();
	void start();
	void end();
};

