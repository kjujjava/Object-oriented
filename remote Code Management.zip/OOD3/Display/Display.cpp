#include "Display.h"
#include <iostream>

Display::Display()
{
}


Display::~Display()
{
}
void Display::start()
{
	std::cout << "\n" << "Uploading Started" <<"\n";
}
void Display::end()
{
	std::cout << "\n" << "Uploading Ended" << "\n" << "Acknowledgedement Received." << "\n" << "File uploaded succesfully";
}
#ifdef TEST_Display
int main()
{
	Display *d = new Display();
	d->start();
	d->end();

}
#endif