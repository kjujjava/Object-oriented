/////////////////////////////////////////////////////////////////////////
// Receiver.h - Receiver receives the message from server and writes   //
//              the message body to a file.                             //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  Provides class that writes filebody from message to a file.
*  Receivemsg():
*  Receives message and takes filebody from the messages and writes them 
*  into a newly created file.
*  Required Files:
*  ---------------
*  Receiver.h, Receiver.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9th Apr 15
*/
#pragma once
#include <string>
#include <fstream>
class Receiver
{
public:
	Receiver();
	~Receiver();
	void receivemsg(std::string msg, std::ofstream &os);
};
