//
//  PlacesTableViewController.h
//  FTripp
//
//
//  Authors: Krishna Teja Medavarapu, Sri Charan Gummadi, Kiran Jujjavarapu
//

#import <UIKit/UIKit.h>
#include<sqlite3.h>
#import <CoreLocation/CoreLocation.h>

@interface PlacesTableViewController : UITableViewController

@end
