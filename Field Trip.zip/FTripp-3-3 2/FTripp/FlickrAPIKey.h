//
//  FlickrAPIKey.h
//  FTripp
//
//
//  Authors: Krishna Teja Medavarapu, Sri Charan Gummadi, Kiran Jujjavarapu
//

#define FlickrAPIKey @"2c86a9df9f7e7520693330f4a578ee5a"
