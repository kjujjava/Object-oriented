//
//  ImageViewController.h
//  FTripp
//
//
//  Authors: Krishna Teja Medavarapu, Sri Charan Gummadi, Kiran Jujjavarapu
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

@property (nonatomic,strong) NSURL *imageURL; //URL of the image to be downloaded.


@end
